import React, { Component } from 'react';

class FooterComponent extends Component {
    render() {
        return (
            <div>
                <footer className='footer'>
                    <span className='test-muted'> All Rights Reserved 2022 @javaStarDotCom</span>
                </footer>
            </div>
        );
    }
}

export default FooterComponent;